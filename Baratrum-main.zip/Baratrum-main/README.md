# Baratrum

Учебный статический сайт сервиса такси и каршеринга: HTML + CSS + ванильный JS, без сборки и бэкенда.
Данные (пользователи, карты, заявки) хранятся в `localStorage`.

## Структура

```
css/    common.css — общая база, остальные подключают её через @import
js/     auth-check.js — ядро (хранилище, сессии, тосты), далее по страницам
assets/ images — изображения и иконки
```

## Изображения и лицензии

Фотографии взяты из [Wikimedia Commons](https://commons.wikimedia.org), портреты для отзывов — из набора [randomuser.me](https://randomuser.me).

| Файл | Сюжет | Автор | Лицензия |
| --- | --- | --- | --- |
| `banner-city-night.jpg` | Улица ночью с такси | Pattaya Patrol | CC BY-SA 4.0 |
| `header-taxi.jpg` | Ряд такси в Нью-Йорке | David R. Tribble | CC BY-SA 3.0 |
| `header-carsharing.jpg` | Парковка прокатных авто | Mattes | Public domain |
| `header-offers.jpg` | Трасса с дрона | Tulen Travel | CC0 |
| `tariff-budget.jpg` | Lada Vesta | Sergey Rodovnichenko | CC BY-SA 2.0 |
| `tariff-economy.jpg` | Kia Rio sedan | — | Public domain |
| `tariff-comfort.jpg` | Toyota Camry | Damian B Oh | CC BY-SA 4.0 |
| `tariff-business.jpg` | Mercedes-Benz E-Class | Dinkun Chen | CC BY-SA 4.0 |
| `tariff-sport.jpg` | Ford Mustang GT | Vauxford | CC BY-SA 4.0 |
| `car-economy.jpg` | Volkswagen Polo sedan | LuvsMG481 | CC BY-SA 4.0 |
| `car-comfort.jpg` | Skoda Octavia Combi RS | Alexander Migl | CC BY-SA 4.0 |
| `car-sport.jpg` | Porsche 718 Cayman | 多多123 | CC BY 4.0 |
| `car-premium.jpg` | BMW 5 Series | Dinkun Chen | CC BY-SA 4.0 |
| `avatar-*.jpg` | Портреты для отзывов | randomuser.me | свободно |

Векторные иконки (`icon-*.svg`, `social-*.svg`) нарисованы вручную. QR-код `qr.svg` ведёт на [@BaratrumOfficial](https://t.me/BaratrumOfficial).
