/* ==========================================================================
   Baratrum — общий слой данных и утилиты + защита страниц
   Подключается на auth.html и profile.html (до страничного скрипта).
   Всё хранится в localStorage: это учебный проект без бэкенда,
   поэтому «хеш» пароля здесь только для вида, а не для защиты.
   ========================================================================== */
(function () {
    'use strict';

    var KEYS = {
        users: 'baratrum:users',
        session: 'baratrum:session',
        applications: 'baratrum:applications',
        cards: 'baratrum:cards:'
    };

    var SESSION_TTL = 1000 * 60 * 60 * 24 * 30; // 30 дней для «запомнить меня»

    /* ----------------------------------------------------------------------
       Чтение/запись localStorage
       ---------------------------------------------------------------------- */
    function read(key, fallback) {
        try {
            var raw = localStorage.getItem(key);
            return raw ? JSON.parse(raw) : fallback;
        } catch (e) {
            return fallback;
        }
    }

    function write(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (e) {
            return false;
        }
    }

    function remove(key) {
        try {
            localStorage.removeItem(key);
        } catch (e) { /* приватный режим — игнорируем */ }
    }

    /* ----------------------------------------------------------------------
       Мелкие утилиты
       ---------------------------------------------------------------------- */
    function uid(prefix) {
        return (prefix || 'id') + '-' + Date.now().toString(36) + '-' +
            Math.random().toString(36).slice(2, 7);
    }

    // Учебный «хеш» (djb2). Не для реального продакшена.
    function hash(value) {
        var str = String(value) + '::baratrum';
        var h = 5381;
        for (var i = 0; i < str.length; i++) {
            h = ((h << 5) + h + str.charCodeAt(i)) >>> 0;
        }
        return h.toString(36);
    }

    function digits(value) {
        return String(value || '').replace(/\D/g, '');
    }

    // 79991234567 -> "+7 (999) 123-45-67"
    function formatPhone(value) {
        var d = digits(value);
        if (d[0] === '8') d = '7' + d.slice(1);
        if (d && d[0] !== '7') d = '7' + d;
        d = d.slice(0, 11);

        var out = '+7';
        if (d.length > 1) out += ' (' + d.slice(1, 4);
        if (d.length >= 5) out += ') ' + d.slice(4, 7);
        if (d.length >= 8) out += '-' + d.slice(7, 9);
        if (d.length >= 10) out += '-' + d.slice(9, 11);
        return out;
    }

    // Вешает маску на input
    function maskPhone(input) {
        if (!input) return;
        input.addEventListener('input', function () {
            var wasAtEnd = input.selectionStart === input.value.length;
            input.value = formatPhone(input.value);
            if (wasAtEnd) {
                try { input.setSelectionRange(input.value.length, input.value.length); } catch (e) { }
            }
        });
        input.addEventListener('focus', function () {
            if (!input.value) input.value = '+7 (';
        });
        input.addEventListener('blur', function () {
            if (digits(input.value).length <= 1) input.value = '';
        });
    }

    function isEmail(value) {
        return /^[^\s@]+@[^\s@]+\.[a-zA-Zа-яА-Я]{2,}$/.test(String(value).trim());
    }

    function isPhone(value) {
        return digits(value).length === 11;
    }

    function formatDate(iso) {
        if (!iso) return '—';
        var d = new Date(iso);
        if (isNaN(d.getTime())) return String(iso);
        return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });
    }

    // 1 заявка / 2 заявки / 5 заявок
    function plural(n, one, few, many) {
        var abs = Math.abs(n) % 100;
        var last = abs % 10;
        if (abs > 10 && abs < 20) return many;
        if (last === 1) return one;
        if (last >= 2 && last <= 4) return few;
        return many;
    }

    /* ----------------------------------------------------------------------
       Уведомления.
       CSS показывает блок, как только в нём появляется текст (:not(:empty)),
       и скрывает по классу .hidden.
       ---------------------------------------------------------------------- */
    var notifyTimer = null;

    function notifyElement() {
        var el = document.getElementById('notification');
        if (el) return el;

        el = document.createElement('div');
        el.id = 'notification';
        el.className = 'notification';
        el.setAttribute('role', 'status');
        document.body.appendChild(el);
        return el;
    }

    function notify(text, type, timeout) {
        var el = notifyElement();
        el.classList.remove('success', 'error', 'hidden');
        el.classList.add(type === 'error' ? 'error' : 'success');
        el.textContent = text;

        clearTimeout(notifyTimer);
        notifyTimer = setTimeout(function () {
            el.classList.add('hidden');
            setTimeout(function () { el.textContent = ''; }, 250);
        }, timeout || 3800);
    }

    /* ----------------------------------------------------------------------
       Пользователи и сессия
       ---------------------------------------------------------------------- */
    function getUsers() {
        return read(KEYS.users, []);
    }

    function saveUsers(list) {
        write(KEYS.users, list);
    }

    function findByPhone(phone) {
        var d = digits(phone);
        return getUsers().filter(function (u) { return u.phone === d; })[0] || null;
    }

    function currentUser() {
        var s = read(KEYS.session, null);
        if (!s || !s.userId) return null;
        if (s.expires && Date.now() > s.expires) {
            remove(KEYS.session);
            return null;
        }
        return getUsers().filter(function (u) { return u.id === s.userId; })[0] || null;
    }

    function startSession(userId, remember) {
        write(KEYS.session, {
            userId: userId,
            remember: !!remember,
            startedAt: Date.now(),
            expires: remember ? Date.now() + SESSION_TTL : null
        });
    }

    function logout() {
        remove(KEYS.session);
    }

    // Персональная скидка: базовая + бонус за активность, максимум 25%
    function discountFor(user) {
        var base = user && typeof user.discount === 'number' ? user.discount : 3;
        var count = getApplications(user ? user.id : '').length;
        var bonus = Math.min(10, count);
        var percent = Math.min(25, base + bonus);

        var steps = [5, 10, 15, 20, 25];
        var level = 'Старт';
        for (var i = 0; i < steps.length; i++) {
            if (percent >= steps[i]) level = ['Бронза', 'Серебро', 'Золото', 'Платина', 'Максимум'][i];
        }
        var next = null;
        for (var j = 0; j < steps.length; j++) {
            if (steps[j] > percent) { next = steps[j]; break; }
        }

        return {
            percent: percent,
            level: level,
            next: next,
            needApps: next === null ? 0 : Math.max(0, (next - base) - count),
            applications: count
        };
    }

    /* ----------------------------------------------------------------------
       Банковские карты
       ---------------------------------------------------------------------- */
    function getCards(userId) {
        return read(KEYS.cards + userId, []);
    }

    function saveCards(userId, list) {
        write(KEYS.cards + userId, list);
    }

    function addCard(userId, card) {
        var list = getCards(userId);
        card.id = uid('card');
        card.createdAt = Date.now();
        if (!list.length) card.isDefault = true;
        list.push(card);
        saveCards(userId, list);
        return card;
    }

    function removeCard(userId, cardId) {
        var list = getCards(userId).filter(function (c) { return c.id !== cardId; });
        if (list.length && !list.some(function (c) { return c.isDefault; })) {
            list[0].isDefault = true;
        }
        saveCards(userId, list);
        return list;
    }

    function cardBrand(number) {
        var d = digits(number);
        if (d.slice(0, 2) === '22') return 'МИР';
        if (d[0] === '4') return 'VISA';
        if (/^5[1-5]/.test(d) || /^2[2-7]/.test(d)) return 'Mastercard';
        return 'Карта';
    }

    /* ----------------------------------------------------------------------
       Заявки
       ---------------------------------------------------------------------- */
    function getApplications(userId) {
        var all = read(KEYS.applications, []);
        if (!userId) return all;
        return all.filter(function (a) { return a.userId === userId; });
    }

    function addApplication(app) {
        var all = read(KEYS.applications, []);
        app.id = uid('BT');
        app.createdAt = Date.now();
        app.status = 'Новая';
        all.push(app);
        // Храним последние 100 заявок, чтобы не раздувать хранилище
        write(KEYS.applications, all.slice(-100));
        return app;
    }

    /* ----------------------------------------------------------------------
       Публичное API
       ---------------------------------------------------------------------- */
    window.Baratrum = {
        keys: KEYS,
        read: read,
        write: write,
        remove: remove,
        uid: uid,
        hash: hash,
        digits: digits,
        formatPhone: formatPhone,
        maskPhone: maskPhone,
        isEmail: isEmail,
        isPhone: isPhone,
        formatDate: formatDate,
        plural: plural,
        notify: notify,
        getUsers: getUsers,
        saveUsers: saveUsers,
        findByPhone: findByPhone,
        currentUser: currentUser,
        startSession: startSession,
        logout: logout,
        discountFor: discountFor,
        getCards: getCards,
        saveCards: saveCards,
        addCard: addCard,
        removeCard: removeCard,
        cardBrand: cardBrand,
        getApplications: getApplications,
        addApplication: addApplication
    };

    /* ----------------------------------------------------------------------
       Защита страниц
       -------------------------------------------------------------------------- */
    var page = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
    var user = currentUser();

    if (page === 'profile.html' && !user) {
        notify('Сначала войдите в аккаунт', 'error');
        setTimeout(function () { location.replace('auth.html'); }, 900);
    }

    if (page === 'auth.html' && user) {
        notify('Вы уже вошли — переходим в профиль');
        setTimeout(function () { location.replace('profile.html'); }, 900);
    }
})();
