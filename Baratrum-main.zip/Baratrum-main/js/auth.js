/* ==========================================================================
   Baratrum — вход и регистрация (auth.html)
   Вкладки, маски, валидация, индикатор надёжности пароля.
   Зависит от js/auth-check.js (window.Baratrum).
   ========================================================================== */
(function () {
    'use strict';

    var B = window.Baratrum;
    if (!B) return;

    var tabs = document.querySelectorAll('.auth-tab');
    var panels = {
        login: document.getElementById('loginForm'),
        register: document.getElementById('registerForm')
    };
    var loginForm = document.getElementById('loginFormElement');
    var registerForm = document.getElementById('registerFormElement');

    if (!panels.login || !panels.register || !loginForm || !registerForm) return;

    /* ----------------------------------------------------------------------
       Вкладки
       ---------------------------------------------------------------------- */
    function activate(name, silent) {
        tabs.forEach(function (tab) {
            tab.classList.toggle('active', tab.dataset.tab === name);
        });
        Object.keys(panels).forEach(function (key) {
            panels[key].classList.toggle('active', key === name);
        });
        B.write('baratrum:lastTab', name);
        if (!silent) clearErrors();
    }

    tabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            activate(tab.dataset.tab);
        });
    });

    var lastTab = B.read('baratrum:lastTab', 'login');
    activate(lastTab === 'register' ? 'register' : 'login', true);

    /* ----------------------------------------------------------------------
       Ошибки в полях
       ---------------------------------------------------------------------- */
    function markError(input, message) {
        input.classList.add('field-invalid');
        input.title = message;

        var hint = input.parentNode.querySelector('.field-error');
        if (!hint) {
            hint = document.createElement('span');
            hint.className = 'field-error';
            input.parentNode.appendChild(hint);
        }
        hint.textContent = message;
        return false;
    }

    function clearError(input) {
        input.classList.remove('field-invalid');
        input.removeAttribute('title');
        var hint = input.parentNode.querySelector('.field-error');
        if (hint) hint.remove();
    }

    function clearErrors(form) {
        (form || document).querySelectorAll('.field-invalid').forEach(clearError);
    }

    [loginForm, registerForm].forEach(function (form) {
        form.addEventListener('input', function (e) {
            if (e.target.classList.contains('field-invalid')) clearError(e.target);
        });
    });

    /* ----------------------------------------------------------------------
       Надёжность пароля
       ---------------------------------------------------------------------- */
    function attachStrength(input) {
        if (!input) return;

        var meter = document.createElement('div');
        meter.className = 'password-meter';
        meter.innerHTML =
            '<span class="password-meter-bar"><i></i></span>' +
            '<span class="password-meter-label">Пароль: —</span>';
        input.parentNode.appendChild(meter);

        var fill = meter.querySelector('i');
        var label = meter.querySelector('.password-meter-label');

        input.addEventListener('input', function () {
            var value = input.value;
            var score = 0;
            if (value.length >= 6) score++;
            if (value.length >= 10) score++;
            if (/[A-ZА-Я]/.test(value) && /[a-zа-я]/.test(value)) score++;
            if (/\d/.test(value)) score++;
            if (/[^\w\sА-Яа-яЁё]/.test(value)) score++;

            var levels = [
                { text: 'слишком короткий', cls: 'weak' },
                { text: 'слабый', cls: 'weak' },
                { text: 'средний', cls: 'medium' },
                { text: 'хороший', cls: 'medium' },
                { text: 'надёжный', cls: 'strong' },
                { text: 'отличный', cls: 'strong' }
            ];
            var level = levels[value ? score : 0];

            fill.style.width = (score / 5) * 100 + '%';
            meter.className = 'password-meter ' + level.cls;
            label.textContent = 'Пароль: ' + level.text;
        });
    }

    /* ----------------------------------------------------------------------
       Показ/скрытие пароля
       ---------------------------------------------------------------------- */
    function attachEye(input) {
        if (!input) return;

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'password-toggle';
        btn.textContent = '👁';
        btn.setAttribute('aria-label', 'Показать пароль');
        input.parentNode.appendChild(btn);
        input.parentNode.classList.add('has-toggle');

        btn.addEventListener('click', function () {
            var shown = input.type === 'text';
            input.type = shown ? 'password' : 'text';
            btn.textContent = shown ? '👁' : '🙈';
            input.focus();
        });
    }

    var loginPhone = document.getElementById('loginPhone');
    var loginPassword = document.getElementById('loginPassword');
    var registerPhone = document.getElementById('registerPhone');
    var registerEmail = document.getElementById('registerEmail');
    var registerName = document.getElementById('registerName');
    var registerCity = document.getElementById('registerCity');
    var registerBirthday = document.getElementById('registerBirthday');
    var registerPassword = document.getElementById('registerPassword');
    var registerPasswordConfirm = document.getElementById('registerPasswordConfirm');

    B.maskPhone(loginPhone);
    B.maskPhone(registerPhone);
    attachStrength(registerPassword);
    attachEye(loginPassword);
    attachEye(registerPassword);
    attachEye(registerPasswordConfirm);

    // Полю даты рождения ставим разумный максимум
    if (registerBirthday) {
        registerBirthday.max = new Date().toISOString().slice(0, 10);
    }

    /* ----------------------------------------------------------------------
       Вход
       ---------------------------------------------------------------------- */
    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();
        clearErrors(loginForm);

        var ok = true;
        if (!B.isPhone(loginPhone.value)) ok = markError(loginPhone, 'Введите номер из 11 цифр');
        if (loginPassword.value.length < 6) ok = markError(loginPassword, 'Минимум 6 символов');
        if (!ok) {
            B.notify('Проверьте данные входа', 'error');
            return;
        }

        var user = B.findByPhone(loginPhone.value);
        if (!user) {
            markError(loginPhone, 'Аккаунт с таким номером не найден');
            B.notify('Такого аккаунта нет — зарегистрируйтесь', 'error');
            return;
        }
        if (user.passwordHash !== B.hash(loginPassword.value)) {
            markError(loginPassword, 'Неверный пароль');
            B.notify('Неверный пароль', 'error');
            return;
        }

        B.startSession(user.id, document.getElementById('rememberMe').checked);
        B.notify('Добро пожаловать, ' + user.name + '!');
        setTimeout(function () { location.href = 'profile.html'; }, 700);
    });

    /* ----------------------------------------------------------------------
       Регистрация
       ---------------------------------------------------------------------- */
    registerForm.addEventListener('submit', function (e) {
        e.preventDefault();
        clearErrors(registerForm);

        var ok = true;
        var name = registerName.value.trim();
        var email = registerEmail.value.trim();
        var city = registerCity.value.trim();
        var birthday = registerBirthday.value;

        if (!B.isPhone(registerPhone.value)) ok = markError(registerPhone, 'Введите номер из 11 цифр');
        else if (B.findByPhone(registerPhone.value)) ok = markError(registerPhone, 'Такой номер уже зарегистрирован');

        if (!B.isEmail(email)) ok = markError(registerEmail, 'Некорректная почта');
        if (name.length < 2) ok = markError(registerName, 'Минимум 2 символа');
        else if (!/^[А-Яа-яA-Za-z\s-]+$/.test(name)) ok = markError(registerName, 'Только буквы');
        if (city.length < 2) ok = markError(registerCity, 'Укажите город');

        var years = birthday ? (Date.now() - new Date(birthday).getTime()) / 3.15576e10 : 0;
        if (!birthday) ok = markError(registerBirthday, 'Укажите дату рождения');
        else if (years < 18) ok = markError(registerBirthday, 'Регистрация с 18 лет');
        else if (years > 100) ok = markError(registerBirthday, 'Проверьте дату');

        if (registerPassword.value.length < 6) ok = markError(registerPassword, 'Минимум 6 символов');
        if (registerPasswordConfirm.value !== registerPassword.value || !registerPasswordConfirm.value) {
            ok = markError(registerPasswordConfirm, 'Пароли не совпадают');
        }

        if (!ok) {
            B.notify('Проверьте выделенные поля', 'error');
            return;
        }

        var phone = B.digits(registerPhone.value);
        var users = B.getUsers();
        var user = {
            id: B.uid('user'),
            phone: phone,
            email: email,
            name: name,
            city: city,
            birthday: birthday,
            passwordHash: B.hash(registerPassword.value),
            createdAt: Date.now(),
            // Персональная скидка 3–14% — детерминированно зависит от номера
            discount: 3 + (parseInt(B.hash(phone), 36) % 12)
        };

        users.push(user);
        B.saveUsers(users);
        B.startSession(user.id, true);

        registerForm.reset();
        B.notify('Аккаунт создан! Скидка ' + user.discount + '% уже активна');
        setTimeout(function () { location.href = 'profile.html'; }, 900);
    });
})();
