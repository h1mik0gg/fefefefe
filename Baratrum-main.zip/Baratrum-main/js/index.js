/* ==========================================================================
   Baratrum — главная страница (index.html)
   Форма заявки с живым расчётом стоимости, конфетти при отправке,
   появление блоков при скролле и лёгкий параллакс баннера.
   Скрипт самодостаточен: работает и без авторизации, и без других модулей.
   ========================================================================== */
(function () {
    'use strict';

    var form = document.getElementById('applicationForm');
    var serviceType = document.getElementById('serviceType');
    var taxiFields = document.getElementById('taxiFields');
    var carsharingFields = document.getElementById('carsharingFields');
    var reduceMotion = window.matchMedia &&
        window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ----------------------------------------------------------------------
       Уведомление (своя копия — страница не подключает auth-check.js)
       ---------------------------------------------------------------------- */
    var notifyTimer = null;

    function notify(text, type) {
        var el = document.getElementById('notification');
        if (!el) {
            el = document.createElement('div');
            el.id = 'notification';
            el.className = 'notification';
            document.body.appendChild(el);
        }
        el.classList.remove('success', 'error', 'hidden');
        el.classList.add(type === 'error' ? 'error' : 'success');
        el.textContent = text;

        clearTimeout(notifyTimer);
        notifyTimer = setTimeout(function () {
            el.classList.add('hidden');
            setTimeout(function () { el.textContent = ''; }, 250);
        }, 4200);
    }

    /* ----------------------------------------------------------------------
       Тарифы: старт, ₽/км, ₽/мин
       ---------------------------------------------------------------------- */
    var RATES = {
        taxi: {
            budget: { name: 'Бюджет', start: 119, km: 12, min: 6 },
            economy: { name: 'Эконом', start: 149, km: 15, min: 7 },
            comfort: { name: 'Комфорт', start: 249, km: 22, min: 9 },
            business: { name: 'Бизнес', start: 499, km: 35, min: 14 },
            hyper: { name: 'Гипер', start: 1499, km: 75, min: 25 }
        },
        carsharing: {
            economy: { name: 'Эконом', start: 99, km: 9, min: 5 },
            comfort: { name: 'Комфорт', start: 199, km: 14, min: 7 },
            sport: { name: 'Спорт', start: 999, km: 40, min: 18 },
            premium: { name: 'Премиум', start: 699, km: 28, min: 13 }
        }
    };

    function money(value) {
        return Math.round(value).toLocaleString('ru-RU') + ' ₽';
    }

    // Детерминированная «оценка» расстояния из адресов (без карты это игрушка,
    // поэтому результат всегда подписан как предварительный)
    function pseudoDistance(seed) {
        var str = String(seed) || 'baratrum';
        var h = 7;
        for (var i = 0; i < str.length; i++) {
            h = (h * 31 + str.charCodeAt(i)) >>> 0;
        }
        return 3 + (h % 24); // 3–26 км
    }

    // "5 дней", "неделя", "месяц", "10" -> количество дней
    function parseDays(value) {
        var str = String(value || '').toLowerCase();
        if (/месяц/.test(str)) return 30;
        if (/недел|7 дн/.test(str)) return 7;
        var m = str.match(/\d+/);
        if (m) return Math.min(365, parseInt(m[0], 10));
        return 1;
    }

    function estimate() {
        var type = serviceType.value;
        if (!type) return null;

        var table = RATES[type];
        var tariffKey = type === 'taxi'
            ? (document.getElementById('taxiTariff') || {}).value
            : (document.getElementById('carsharingTariff') || {}).value;
        var rate = table[tariffKey];
        if (!rate) return null;

        if (type === 'taxi') {
            var from = (document.getElementById('pickupAddress') || {}).value || '';
            var to = (document.getElementById('destinationAddress') || {}).value || '';
            if (!from.trim() || !to.trim()) return null;

            var km = pseudoDistance(from.trim().toLowerCase() + '|' + to.trim().toLowerCase());
            var minutes = Math.max(5, Math.round(km * 2.4));
            return {
                tariff: rate.name,
                route: from.trim() + ' → ' + to.trim(),
                detail: km + ' км · ~' + minutes + ' мин в пути',
                price: rate.start + km * rate.km + minutes * rate.min
            };
        }

        var address = (document.getElementById('orderAddress') || {}).value || '';
        var model = (document.getElementById('carModel') || {}).value || '';
        if (!address.trim()) return null;

        var days = parseDays((document.getElementById('rentalPeriod') || {}).value);
        var km = pseudoDistance(address.trim().toLowerCase() + '|' + model.trim().toLowerCase());
        var perDay = rate.start + km * rate.km * 0.6 + 120 * rate.min * 0.6;
        return {
            tariff: rate.name,
            route: (model.trim() || 'Авто на выбор') + ' · ' + address.trim(),
            detail: days + ' ' + plural(days, 'день', 'дня', 'дней') + ' · ~' + km + ' км/сутки',
            price: perDay * days
        };
    }

    function plural(n, one, few, many) {
        var abs = Math.abs(n) % 100;
        var last = abs % 10;
        if (abs > 10 && abs < 20) return many;
        if (last === 1) return one;
        if (last >= 2 && last <= 4) return few;
        return many;
    }

    /* ----------------------------------------------------------------------
       Блок предпросмотра стоимости
       ---------------------------------------------------------------------- */
    var preview = null;

    function ensurePreview() {
        if (preview) return preview;
        preview = document.createElement('div');
        preview.className = 'form-preview';
        preview.innerHTML =
            '<span class="form-preview-label">Предварительно</span>' +
            '<strong class="form-preview-price"></strong>' +
            '<span class="form-preview-note"></span>';
        form.insertBefore(preview, form.querySelector('.submit-btn'));
        return preview;
    }

    function renderPreview() {
        var box = ensurePreview();
        var data = estimate();

        if (!data) {
            box.classList.remove('is-visible');
            box.removeAttribute('data-ready');
            return;
        }

        box.querySelector('.form-preview-price').textContent = money(data.price);
        box.querySelector('.form-preview-note').textContent =
            data.tariff + ' · ' + data.route + ' · ' + data.detail +
            ' · без пробок и повышающих коэффициентов';
        box.classList.add('is-visible');
    }

    /* ----------------------------------------------------------------------
       Переключение блоков услуги
       ---------------------------------------------------------------------- */
    function switchService() {
        var type = serviceType.value;
        taxiFields.style.display = type === 'taxi' ? 'block' : 'none';
        carsharingFields.style.display = type === 'carsharing' ? 'block' : 'none';

        [taxiFields, carsharingFields].forEach(function (block) {
            var active = block.style.display !== 'none';
            block.querySelectorAll('input, select, textarea').forEach(function (el) {
                if (!el.dataset.optional) el.required = active;
            });
        });
        renderPreview();
    }

    serviceType.addEventListener('change', switchService);
    form.addEventListener('input', renderPreview);
    form.addEventListener('change', renderPreview);

    /* ----------------------------------------------------------------------
       Отправка заявки
       ---------------------------------------------------------------------- */
    function saveApplication(app) {
        var list = [];
        try {
            list = JSON.parse(localStorage.getItem('baratrum:applications') || '[]');
        } catch (e) { list = []; }
        list.push(app);
        try {
            localStorage.setItem('baratrum:applications', JSON.stringify(list.slice(-100)));
        } catch (e) { /* приватный режим */ }
    }

    function applicationsCount() {
        try {
            return JSON.parse(localStorage.getItem('baratrum:applications') || '[]').length;
        } catch (e) { return 0; }
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();

        var type = serviceType.value;
        if (!type) return notify('Выберите тип услуги', 'error');

        var data = estimate();
        if (!data) {
            return notify(type === 'taxi'
                ? 'Заполните тариф и оба адреса'
                : 'Заполните тариф и адрес заказа', 'error');
        }

        var app = {
            service: type,
            tariff: data.tariff,
            route: data.route,
            comment: (type === 'taxi'
                ? (document.getElementById('taxiComment') || {}).value
                : (document.getElementById('carsharingComment') || {}).value) || '',
            estimate: Math.round(data.price),
            createdAt: Date.now()
        };

        // Если пользователь авторизован — привязываем заявку к аккаунту
        try {
            var session = JSON.parse(localStorage.getItem('baratrum:session') || 'null');
            if (session && session.userId) app.userId = session.userId;
        } catch (err) { /* гость */ }

        var number = 'BT-' + new Date().getFullYear() + '-' +
            String(Date.now()).slice(-5);
        app.number = number;
        saveApplication(app);

        notify('Заявка ' + number + ' принята · ' + money(data.price) +
            ' · всего заявок: ' + applicationsCount());
        confetti();

        form.reset();
        switchService();
    });

    /* ----------------------------------------------------------------------
       Конфетти
       ---------------------------------------------------------------------- */
    function confetti() {
        if (reduceMotion) return;

        var canvas = document.createElement('canvas');
        canvas.className = 'confetti';
        document.body.appendChild(canvas);

        var ctx = canvas.getContext('2d');
        var dpr = window.devicePixelRatio || 1;
        canvas.width = innerWidth * dpr;
        canvas.height = innerHeight * dpr;
        ctx.scale(dpr, dpr);

        var colors = ['#ffc93c', '#14161a', '#2fa96b', '#e5484d', '#ffffff'];
        var parts = [];
        for (var i = 0; i < 120; i++) {
            parts.push({
                x: innerWidth / 2 + (Math.random() - 0.5) * 200,
                y: innerHeight * 0.35,
                vx: (Math.random() - 0.5) * 9,
                vy: -Math.random() * 11 - 3,
                size: 5 + Math.random() * 6,
                color: colors[i % colors.length],
                rot: Math.random() * Math.PI,
                vr: (Math.random() - 0.5) * 0.3
            });
        }

        var start = performance.now();
        // Страховка: если rAF не доживёт (фоновая вкладка), полотно уберётся само
        setTimeout(function () { canvas.remove(); }, 4000);

        (function frame(now) {
            var t = now - start;
            ctx.clearRect(0, 0, innerWidth, innerHeight);

            parts.forEach(function (p) {
                p.vy += 0.32;
                p.x += p.vx;
                p.y += p.vy;
                p.rot += p.vr;

                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rot);
                ctx.globalAlpha = Math.max(0, 1 - t / 2200);
                ctx.fillStyle = p.color;
                ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
                ctx.restore();
            });

            if (t < 2200) {
                requestAnimationFrame(frame);
            } else {
                canvas.remove();
            }
        })(start);
    }

    /* ----------------------------------------------------------------------
       Появление блоков при скролле
       Класс вешается только из JS — без скриптов контент просто виден.
       ---------------------------------------------------------------------- */
    var targets = document.querySelectorAll('.advantages h1, .adv-item, .user-comment h1, .comment-card, .application-form');

    if (!reduceMotion && 'IntersectionObserver' in window) {
        targets.forEach(function (el, i) {
            el.classList.add('reveal');
            el.style.transitionDelay = (i % 6) * 60 + 'ms';
        });

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12 });

        targets.forEach(function (el) { observer.observe(el); });
    }

    /* ----------------------------------------------------------------------
       Параллакс баннера
       ---------------------------------------------------------------------- */
    var banner = document.querySelector('.background-baner');
    if (banner && !reduceMotion) {
        var lastRun = 0;
        window.addEventListener('scroll', function () {
            var now = Date.now();
            if (now - lastRun < 16) return; // ~60 fps, без зависимости от rAF
            lastRun = now;

            var offset = Math.min(window.scrollY, 560);
            banner.style.transform = 'translateY(' + (offset * 0.25).toFixed(1) + 'px) scale(1.06)';
        }, { passive: true });
    }

    switchService();
})();
