/* ==========================================================================
   Baratrum — профиль (profile.html)
   Личные данные, привязанные карты, персональная скидка.
   Зависит от js/auth-check.js (window.Baratrum).
   ========================================================================== */
(function () {
    'use strict';

    var B = window.Baratrum;
    if (!B) return;

    var user = B.currentUser();
    if (!user) return; // редирект делает auth-check.js

    var personalInfo = document.getElementById('personalInfo');
    var editBtn = document.getElementById('editPersonalBtn');
    var editFormBox = document.getElementById('personalEditForm');

    var cardsList = document.getElementById('cardsList');
    var addCardBtn = document.getElementById('addCardBtn');
    var addCardForm = document.getElementById('addCardForm');
    var cardForm = document.getElementById('cardForm');
    var cancelCardBtn = document.getElementById('cancelCardBtn');
    var discountInfo = document.getElementById('discountInfo');

    var cardNumber = document.getElementById('cardNumber');
    var cardExpiry = document.getElementById('cardExpiry');
    var cardCVC = document.getElementById('cardCVC');
    var cardName = document.getElementById('cardName');

    /* ----------------------------------------------------------------------
       Личная информация
       ---------------------------------------------------------------------- */
    var FIELDS = [
        { key: 'name', label: 'Имя' },
        { key: 'phone', label: 'Телефон', format: function (v) { return B.formatPhone(v); } },
        { key: 'email', label: 'Почта' },
        { key: 'city', label: 'Город' },
        { key: 'birthday', label: 'Дата рождения', format: B.formatDate },
        { key: 'createdAt', label: 'Дата регистрации', format: B.formatDate }
    ];

    function renderPersonal() {
        personalInfo.innerHTML = '';
        FIELDS.forEach(function (field) {
            var raw = user[field.key];
            var item = document.createElement('div');
            item.className = 'info-item';
            item.innerHTML =
                '<span class="info-label"></span>' +
                '<p class="info-value"></p>';
            item.querySelector('.info-label').textContent = field.label;
            item.querySelector('.info-value').textContent =
                field.format ? field.format(raw) : (raw || '—');
            personalInfo.appendChild(item);
        });
    }

    /* ----------------------------------------------------------------------
       Форма редактирования
       ---------------------------------------------------------------------- */
    var EDITABLE = [
        { key: 'name', label: 'Имя', type: 'text', placeholder: 'Ваше имя' },
        { key: 'email', label: 'Почта', type: 'email', placeholder: 'example@mail.com' },
        { key: 'city', label: 'Город', type: 'text', placeholder: 'Ваш город' },
        { key: 'birthday', label: 'Дата рождения', type: 'date', placeholder: '' }
    ];

    function buildEditForm() {
        editFormBox.innerHTML = '';
        var form = document.createElement('form');
        form.className = 'edit-personal-form';
        form.noValidate = true;

        EDITABLE.forEach(function (field, index) {
            var id = 'edit-' + field.key;
            var group = document.createElement('div');
            group.className = 'form-group';
            group.innerHTML =
                '<label for="' + id + '"></label>' +
                '<input id="' + id + '" name="' + field.key + '" type="' + field.type + '">';
            group.querySelector('label').textContent = field.label;
            var input = group.querySelector('input');
            input.value = field.key === 'birthday' ? (user[field.key] || '') : (user[field.key] || '');
            if (field.placeholder) input.placeholder = field.placeholder;
            if (index % 2 === 1) input.dataset.pair = '1';
            form.appendChild(group);
        });

        var actions = document.createElement('div');
        actions.className = 'form-actions';
        actions.innerHTML =
            '<button type="submit" class="submit-btn">Сохранить</button>' +
            '<button type="button" class="cancel-btn js-cancel">Отмена</button>';
        form.appendChild(actions);

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            var next = {
                name: form.elements.name.value.trim(),
                email: form.elements.email.value.trim(),
                city: form.elements.city.value.trim(),
                birthday: form.elements.birthday.value
            };

            if (next.name.length < 2) return B.notify('Имя слишком короткое', 'error');
            if (!B.isEmail(next.email)) return B.notify('Некорректная почта', 'error');
            if (next.city.length < 2) return B.notify('Укажите город', 'error');
            if (next.birthday && new Date(next.birthday) > new Date()) {
                return B.notify('Дата рождения в будущем?', 'error');
            }

            var users = B.getUsers();
            users = users.map(function (u) {
                return u.id === user.id ? Object.assign({}, u, next) : u;
            });
            B.saveUsers(users);
            user = users.filter(function (u) { return u.id === user.id; })[0];

            toggleEdit(false);
            renderPersonal();
            B.notify('Изменения сохранены');
        });

        form.querySelector('.js-cancel').addEventListener('click', function () {
            toggleEdit(false);
        });

        editFormBox.appendChild(form);
    }

    function toggleEdit(show) {
        var open = show === undefined ? editFormBox.style.display === 'none' : show;
        if (open) buildEditForm();
        editFormBox.style.display = open ? 'block' : 'none';
        personalInfo.style.display = open ? 'none' : 'grid';
        editBtn.textContent = open ? 'Отмена' : 'Редактировать';
    }

    if (editBtn) editBtn.addEventListener('click', function () { toggleEdit(); });

    /* ----------------------------------------------------------------------
       Карты
       ---------------------------------------------------------------------- */
    function maskCardNumber(input) {
        if (!input) return;
        input.addEventListener('input', function () {
            var d = B.digits(input.value).slice(0, 16);
            input.value = d.replace(/(.{4})/g, '$1 ').trim();
        });
    }

    function maskExpiry(input) {
        if (!input) return;
        input.addEventListener('input', function () {
            var d = B.digits(input.value).slice(0, 4);
            input.value = d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d;
        });
    }

    function maskCvc(input) {
        if (!input) return;
        input.addEventListener('input', function () {
            input.value = B.digits(input.value).slice(0, 3);
        });
    }

    function renderCards() {
        var cards = B.getCards(user.id);
        cardsList.innerHTML = '';

        if (!cards.length) {
            var empty = document.createElement('p');
            empty.className = 'empty-message';
            empty.textContent = 'Карт пока нет. Добавьте первую — так оплата будет быстрее.';
            cardsList.appendChild(empty);
            return;
        }

        cards.slice().reverse().forEach(function (card) {
            var el = document.createElement('div');
            el.className = 'card-item';
            el.innerHTML =
                '<span class="card-brand"></span>' +
                '<span class="card-number"></span>' +
                '<span class="card-meta"><span class="card-holder"></span><span class="card-exp"></span></span>' +
                '<button type="button" class="card-remove">Удалить</button>';

            var masked = '•••• •••• •••• ' + card.number.slice(-4);
            el.querySelector('.card-brand').textContent = B.cardBrand(card.number) +
                (card.isDefault ? ' · по умолчанию' : '');
            el.querySelector('.card-number').textContent = masked;
            el.querySelector('.card-holder').textContent = card.holder || '—';
            el.querySelector('.card-exp').textContent = card.expiry || '—';

            el.querySelector('.card-remove').addEventListener('click', function () {
                B.removeCard(user.id, card.id);
                renderCards();
                B.notify('Карта ' + masked + ' удалена');
            });

            cardsList.appendChild(el);
        });
    }

    if (addCardBtn) {
        addCardBtn.addEventListener('click', function () {
            addCardForm.style.display = 'block';
            if (cardNumber) cardNumber.focus();
        });
    }

    if (cancelCardBtn) {
        cancelCardBtn.addEventListener('click', function () {
            addCardForm.style.display = 'none';
            if (cardForm) cardForm.reset();
        });
    }

    if (cardForm) {
        cardForm.addEventListener('submit', function (e) {
            e.preventDefault();

            var number = B.digits(cardNumber.value);
            var expiry = cardExpiry.value.trim();
            var cvc = B.digits(cardCVC.value);
            var holder = cardName.value.trim().toUpperCase();

            if (number.length !== 16) return B.notify('Номер карты — 16 цифр', 'error');
            if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(expiry)) return B.notify('Срок действия в формате ММ/ГГ', 'error');

            var parts = expiry.split('/');
            var expDate = new Date(2000 + parseInt(parts[1], 10), parseInt(parts[0], 10), 1);
            if (expDate < new Date()) return B.notify('Срок карты уже истёк', 'error');
            if (cvc.length !== 3) return B.notify('CVC — 3 цифры', 'error');
            if (holder.length < 3) return B.notify('Укажите держателя карты', 'error');

            if (B.getCards(user.id).some(function (c) { return c.number === number; })) {
                return B.notify('Эта карта уже привязана', 'error');
            }

            B.addCard(user.id, {
                number: number,
                expiry: expiry,
                cvc: cvc, // в реальном проекте так делать нельзя — только токен от банка
                holder: holder,
                isDefault: false
            });

            cardForm.reset();
            addCardForm.style.display = 'none';
            renderCards();
            B.notify('Карта •••• ' + number.slice(-4) + ' добавлена');
        });
    }

    maskCardNumber(cardNumber);
    maskExpiry(cardExpiry);
    maskCvc(cardCVC);
    if (cardName) {
        cardName.addEventListener('input', function () {
            cardName.value = cardName.value.toUpperCase().replace(/[^A-ZА-ЯЁ ]/g, '');
        });
    }

    /* ----------------------------------------------------------------------
       Персональная скидка
       ---------------------------------------------------------------------- */
    function renderDiscount() {
        var d = B.discountFor(user);
        var progress = Math.round(d.percent / 25 * 100);

        var hint = d.next === null
            ? 'Максимальная скидка достигнута.'
            : 'До ' + d.next + '% — ещё ' + d.needApps + ' ' +
              B.plural(d.needApps, 'заявка', 'заявки', 'заявок') + '.';

        discountInfo.innerHTML =
            '<div>' +
            '<span class="discount-value">' + d.percent + '%</span>' +
            '<p>Скидка держателя · уровень «' + d.level + '»</p>' +
            '<div class="discount-progress"><i style="width:' + progress + '%"></i></div>' +
            '<p class="discount-hint">' + hint +
            ' Всего заявок: ' + d.applications + '.</p>' +
            '</div>';
    }

    /* ----------------------------------------------------------------------
       Выход
       ---------------------------------------------------------------------- */
    window.logout = function () {
        B.logout();
        B.notify('Вы вышли из аккаунта');
        setTimeout(function () { location.href = 'index.html'; }, 700);
    };

    renderPersonal();
    renderCards();
    renderDiscount();
})();
